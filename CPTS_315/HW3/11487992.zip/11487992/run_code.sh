#!/bin/sh
# This is a comment!

python ./main.py