/**
 * Created by brand on 12/7/2018.
 */
public class Coordinates {
    private int x;
    private int y;

    public Coordinates(){
        x = -1;
        y = -1;
    }

    public int getx() { return this.x; }
    public int gety() { return this.y; }
    public int setx(int newx) { return this.x = newx; }
    public int sety(int newy) { return this.y = newy; }

}
