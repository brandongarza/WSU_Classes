#!/bin/sh
# This is a comment!

python ./src/apriori.py